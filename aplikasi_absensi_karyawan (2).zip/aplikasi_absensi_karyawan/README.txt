APLIKASI ABSENSI KARYAWAN

Cara menjalankan:
1. Ekstrak file ZIP.
2. Buka folder aplikasi.
3. Klik dua kali index.html, lalu buka menggunakan Chrome/Edge/Firefox.
4. Isi formulir dan klik Simpan Absensi.

Fitur:
- Tambah data absensi karyawan
- Edit dan hapus data
- Catat tanggal, jam masuk, jam pulang, jabatan, dan status
- Cari nama/jabatan serta filter tanggal/status
- Ringkasan jumlah kehadiran hari ini
- Ekspor data menjadi CSV untuk dibuka di Excel
- Data tersimpan di localStorage browser pada perangkat yang digunakan

Catatan:
Versi ini adalah prototipe lokal tanpa database online. Data tidak otomatis tersinkron antarperangkat dan dapat hilang jika data browser dihapus. Untuk pemakaian perusahaan secara nyata, tambahkan autentikasi dan database/server.
