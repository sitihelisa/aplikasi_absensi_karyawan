# Aplikasi Absensi Karyawan

Website absensi karyawan sederhana menggunakan HTML, CSS, dan JavaScript.

## Cara menjalankan di GitHub Pages
1. Buat repositori GitHub baru, misalnya `absensi-karyawan`.
2. Ekstrak ZIP ini di komputer.
3. Unggah **isi folder** ke halaman utama repositori. Pastikan `index.html` terlihat langsung di halaman utama, bukan berada di dalam folder lain.
4. Klik **Commit changes**.
5. Buka **Settings → Pages**.
6. Pada **Build and deployment**, pilih **Deploy from a branch**.
7. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
8. Tunggu beberapa menit sampai GitHub Pages selesai menerbitkan situs.

## Alamat situs
Jika nama akun GitHub `sitihelisa` dan nama repositori `absensi-karyawan`, alamat situs biasanya:
`https://sitihelisa.github.io/absensi-karyawan/`

Ganti nama akun atau repositori sesuai yang benar-benar digunakan.

## Fitur
- Tambah, edit, dan hapus absensi
- Nama karyawan, jabatan, tanggal, jam masuk, jam pulang
- Status Hadir, Izin, Sakit, Alpa
- Pencarian dan filter
- Ringkasan kehadiran hari ini
- Ekspor CSV untuk dibuka di Excel

## Catatan
Data disimpan di browser yang digunakan (localStorage), bukan di server. Data tidak otomatis tersinkron antarperangkat. Untuk penggunaan banyak pengguna/komputer, diperlukan database dan autentikasi.
